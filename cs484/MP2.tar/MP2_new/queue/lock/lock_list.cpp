#include "list.h"
#include <thread>
#include <mutex>

std::mutex node_lock;

bool insert_node_lock(list *&l,int tid)
{
	if(is_full_lock(l)) return false;
	
	node_lock.lock();
	
	// add code here to insert an element into the list (FIFO)
	
	node_lock.unlock();

	return true;
}


bool delete_node_lock(list *&l,int tid)
{
	if(is_empty_lock(l)) return false;

	node_lock.lock();
	
	// add code here to delete an element from the list (FIFO)

	node_lock.unlock();
	
	return true;

}
