#ifndef __NODE_H_
#define __NODE_H_

struct node
{
	int value;
	node *next;  // use this pointer if you are using a linked list implementation
};

#endif
