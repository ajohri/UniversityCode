#include "list.h"
#include <thread>
#include <mutex>

bool insert_front_lf(list *&l, int tid)
{
	
	if(is_full_lf(l)) return false;
	
	// add code here to insert an element into the list (FIFO)

	return true;
}

bool delete_back_lf(list *&l,int tid)
{
	
	if(is_empty_lf(l)) return false;


	// add code here to remove an element from the list (FIFO)
	
	return true;
}
