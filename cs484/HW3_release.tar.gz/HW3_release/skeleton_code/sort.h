#ifndef __SORT_H_
#define __SORT_H_

#include <cassert>
#include <cstdio>
#include <iostream>
#include <climits>



typedef int key;


void findSplitters(uint64_t *histCounts, key *probes, int probeSize,
               int nBuckets, 
               key *splitters, uint64_t *bucketCounts);



#endif




