#include "sort.h"
#include <algorithm>
#include <mpi.h>
#include <chrono>
#include <random>
#include <climits>

int local_checksum(int *data, int n){
	int keysum = 0;
	for(int i = 0; i < n; i++)
		keysum += (int)(data[i] % 1009);
	return keysum;
}



int main(int argc, char **argv)
{

	int num_elements, num_local;
	int num_pes, myrank;
	int oversampling_ratio = 20;
	int *my_data;

	num_elements = atoi(argv[1]);	
	if(argc > 2)
		oversampling_ratio = atoi(argv[2]);
	
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD, &num_pes);
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);

	num_local = num_elements/num_pes;
	int rem = num_elements%num_pes;
	
	if(myrank < rem) num_local++;			

	int root = 0;


    //!TODO
	//Step 1: populate and sort my_data


	//compute initial checksum
	int local_sum = local_checksum(my_data, num_local);
	int initial_checksum;
	MPI_Reduce(&local_sum, &initial_checksum, 1, MPI_INT,
               MPI_SUM, root, MPI_COMM_WORLD);



    //!TODO
	//Step 2: collect samples from my_data
	int num_samples = oversampling_ratio; //constant at every processor
	int *samples = new int[num_samples];



    //!TODO
	//Step 3: gather samples at root into the probes array
	int *probes;
	int num_probes;
	num_probes = num_pes * num_samples;
	probes = new int[num_probes+1];



	//Step 4: sort probes at root and broadcast
	if(myrank == root){
		std::sort(probes, probes + num_probes);
		probes[num_probes] = INT_MAX; //add maxkey at the end
	}	
	num_probes++;


    //!TODO
	//Step 5: broadcast probes to all processors

	
    //!TODO
	//Step 6: Compute local histogram
	uint64_t *histCounts = new uint64_t[num_probes];
	
	
    //!TODO
	//Step 7: Reduce histCounts at the root
	uint64_t *reducedCounts; //should store the reduced counts


    //!TODO
	//Step 8: Select splitters from reduced count at the root, use findSplitters function in utils.cpp
	int *splitters = new int[num_pes];
	uint64_t *bucketCounts = new uint64_t[num_pes];


    //!TODO
	//Step 9: Broadcast all splitters



	//Step 10: Figure out how many keys to send to each processor
    int *send_counts = new int[num_pes]; //send counts
    for(int i=0; i<num_pes; i++){
        int sep1 = (i>0? splitters[i-1] : INT_MIN);
        int sep2 = splitters[i];
        //find range of keys to send
        int ind1 = std::lower_bound(my_data,
                                my_data + num_local, sep1) - my_data;
        int ind2 = std::lower_bound(my_data,
                                my_data + num_local, sep2) - my_data;
      	//send [my_data[ind1], my_data[ind2]) to processor i (Note the inclusive, exclusive brackets)
        send_counts[i] = ind2 - ind1;
    }


    //!TODO
    //Step 11: Convey to each processor how much data we're going to send to that processor. 



    //!TODO
    //Step 12: Send all keys to the right processor
	int final_num_local; //Will store total number of elements recieved by me
	int *final_my_data;  //Will store recieved keys


    //!TODO
    //Step 13: Sort all received data


	//verify final checksum
	local_sum = local_checksum(final_my_data, final_num_local);
	int final_checksum;
	MPI_Reduce(&local_sum, &final_checksum, 1, MPI_INT,
               MPI_SUM, root, MPI_COMM_WORLD);
	if(myrank == root){
		std::cout<<"Sorting Finished. Inital checksum: "<<initial_checksum<<", Final checksum: "<<final_checksum<<std::endl;
	}

	MPI_Finalize();
	return 0;
}
