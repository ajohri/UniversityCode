#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <papi.h>
#define NUM_FLOPS 10000
#define NUM_EVENTS 2


int main(int argc, char **argv)
{
	int events[NUM_EVENTS] = {PAPI_TOT_INS};
	int retval, EventSet = PAPI_NULL;
	long long values[NUM_EVENTS];
	int A[10024][10024], B[10024][10024];


	retval = PAPI_library_init(PAPI_VER_CURRENT);
	if(retval != PAPI_VER_CURRENT)
	{
		std::cout <<" PAPI library init error"<<std::endl;
		exit(-1);
	}

	if(PAPI_create_eventset(&EventSet)!=PAPI_OK)
	{
		std::cout <<" event set error"<<std::endl;
		exit(-1);
	}

	if(PAPI_add_event(EventSet,PAPI_L1_DCM)!=PAPI_OK)
	{
		std::cout <<" error adding event"<<std::endl;
		exit(-1);
	}

	if(PAPI_add_event(EventSet,PAPI_L2_LDM)!=PAPI_OK)
	{
		std::cout <<" error adding event"<<std::endl;
		exit(-1);
	}

	if(PAPI_start(EventSet)!= PAPI_OK)
	{
	  std::cout <<" counters not initialised"<<std::endl;
	}

	for(int i=0;i<10024;i++)
	for(int j=0;j<10024;j++)
	{
		A[i][j] = A[i][j]+B[i][j];
	}


	if(PAPI_read(EventSet,values)!= PAPI_OK)
	{
	   std::cout <<"counters could not be read"<<std::endl;
	   exit(-1);
	}

	std::cout <<"number of L1 data cache misses = "<<values[0]<<" number of L2 data cache misses = "<<values[1]<<std::endl;



}	
