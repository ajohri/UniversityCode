#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <papi.h>
#define NUM_FLOPS 10000
#define NUM_EVENTS 1


int main(int argc, char **argv)
{
	int events[NUM_EVENTS] = {PAPI_TOT_INS};
	int retval, EventSet = PAPI_NULL;
	long long values[NUM_EVENTS];

	retval = PAPI_library_init(PAPI_VER_CURRENT);
	if(retval != PAPI_VER_CURRENT)
	{
		std::cout <<" PAPI library init error"<<std::endl;
		exit(-1);
	}

	if(PAPI_create_eventset(&EventSet)!=PAPI_OK)
	{
		std::cout <<" event set error"<<std::endl;
		exit(-1);
	}

	if(PAPI_add_event(EventSet,PAPI_TOT_INS)!=PAPI_OK)
	{
		std::cout <<" error adding event"<<std::endl;
		exit(-1);
	}

	if(PAPI_start(EventSet)!= PAPI_OK)
	{
	  std::cout <<" counters not initialised"<<std::endl;
	}
	for(int i=0;i<100000;i++)
	{
		int a = i+1;
		int b = i+2;
		int c = a*b;
	}

	if(PAPI_read(EventSet,values)!= PAPI_OK)
	{
	   std::cout <<"counters could not be read"<<std::endl;
	   exit(-1);
	}

	std::cout <<"number of instructions = "<<values[0]<<std::endl;



}	
