#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <papi.h>

int data;
int eventset;
double start;

double get_clock()
{
	struct timeval tv;
	int ok;
	ok = gettimeofday(&tv,NULL);
	if(ok < 0)
	{
		fprintf(stderr,"Timer gettimeofday error!\n");
		exit(1);
	}
	return tv.tv_sec*1.0+tv.tv_usec*1.0e-6;
}

void papi_setup()
{
	int retval = PAPI_NULL;
	retval = PAPI_library_init(PAPI_VER_CURRENT);
	if(retval != PAPI_VER_CURRENT)
	{
		fprintf(stderr,"PAPI library init error\n");
		exit(1);
	}
	eventset = PAPI_NULL;
	if(PAPI_create_eventset(&eventset) != PAPI_OK)
	{
		fprintf(stderr,"PAPI create eventset error\n");
		exit(1);
	}

	int eventcodes[2];

	switch(data)
	{
		case 0: eventcodes[0] = PAPI_TOT_INS;
			eventcodes[1] = PAPI_FP_OPS;
			break;
		case 1: eventcodes[0] = PAPI_L1_DCM;
			eventcodes[1] = PAPI_LST_INS;
			break;
		case 2: eventcodes[0] = PAPI_L2_DCM;
			eventcodes[1] = PAPI_L2_DCA;
			break;
		case 3: eventcodes[0] = PAPI_L3_TCM;
			eventcodes[1] = PAPI_L3_TCA;
			break;
		default : fprintf(stderr,"Illegal option for eventcodes\n");
			  break;
	}

	if(PAPI_add_events(eventset,eventcodes,2)!=PAPI_OK)
	{
		fprintf(stderr,"PAPI add events error\n");
		exit(1);
	}
}

void papi_start()
{
	  start = get_clock();
	  if(PAPI_start(eventset) != PAPI_OK)
	  {
	  	fprintf(stderr, "PAPI start error!\n");
	  	exit(1);
	  }
}

void papi_report()
{
	 double time = get_clock() - start;
	 long_long values[2];

	if(PAPI_stop(eventset, values) != PAPI_OK) 
	{
	    fprintf(stderr, "PAPI stop error!\n");
	    exit(1);
	}   
	printf("Results:\n");
	printf("Time of execution: %lf\n", time);
	if(data == 0) 
	{
		printf("Total instructions executed: %lld\n", values[0]);
		printf("Floating point operations: %lld\n", values[1]);
	}	
	else 
	{
		printf("L%d Cache:\n\tAccesses: %lld, Hits: %lld, Misses: %lld\n",data, values[1], values[1] - values[0], values[0]);				
	}
}	
